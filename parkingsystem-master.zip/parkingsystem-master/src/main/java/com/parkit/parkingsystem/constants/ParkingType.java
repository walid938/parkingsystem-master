package com.parkit.parkingsystem.constants;

public enum ParkingType {
    CAR,
    BIKE
}
